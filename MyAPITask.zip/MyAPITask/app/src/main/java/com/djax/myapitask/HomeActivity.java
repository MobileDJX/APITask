package com.djax.myapitask;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Timer;
import java.util.TimerTask;

public class HomeActivity extends AppCompatActivity {

    ImageView profileImage;
    private RequestQueue mRequestQueue;
    private StringRequest mStringRequest;
    private static final String TAG = HomeActivity.class.getName();
    private String url = "https://randomuser.me/api/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        profileImage=(ImageView)findViewById(R.id.profile);



        autoRefresh();

    }

    private void autoRefresh()
    {
        //Declare the timer
        Timer t = new Timer();
        //Set the schedule function and rate
        t.scheduleAtFixedRate(new TimerTask() {

                                  @Override
                                  public void run() {
                                      //Called each time when 5000 milliseconds (5 second) (the period parameter)
                                      loadProfile(url);
                                  }

                              },
    //Set how long before to start calling the TimerTask (in milliseconds)
                0,
    //Set the amount of time between each execution (in milliseconds)
                5000);
    }

    private void loadProfile(String url) {

       /* ProgressDialog pDialog = new ProgressDialog(this);
        pDialog.setMessage("Loading...PLease wait");
        pDialog.show();
*/
//RequestQueue initialized
        mRequestQueue = Volley.newRequestQueue(this);

        //String Request initialized
        mStringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

               // Toast.makeText(getApplicationContext(),"Response :" + response.toString(), Toast.LENGTH_LONG).show();//display the response on screen

                try {
                    JSONObject jsonObject=new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("results");
                    for(int i=0;i<jsonArray.length();i++)
                    {
                        JSONObject jObj = jsonArray.getJSONObject(i);
                        String gender = jObj.getString("gender");
                        String email = jObj.getString("email");
                        System.out.println("@@ gender"+gender);
                        JSONObject nameObj=jObj.getJSONObject("name");
                        String title=nameObj.getString("title");
                        String first=nameObj.getString("first");
                        String last=nameObj.getString("last");
                        System.out.println("@@ title"+title);

                        JSONObject dobObj=jObj.getJSONObject("dob");
                        String age=dobObj.getString("age");

                        JSONObject locationObj=jObj.getJSONObject("location");
                        JSONObject streetObj=locationObj.getJSONObject("street");
                        String number=streetObj.getString("number");
                        String adname=streetObj.getString("name");

                        String phone = jObj.getString("phone");

                        JSONObject loginObj=jObj.getJSONObject("login");
                        String password=loginObj.getString("password");

                        JSONObject pictureObj=jObj.getJSONObject("picture");
                        String medium=pictureObj.getString("medium");

                        ((TextView)findViewById(R.id.name)).setText(title+""+first+""+last);
                        ((TextView)findViewById(R.id.email)).setText(email);
                        ((TextView)findViewById(R.id.dob)).setText(age);
                        ((TextView)findViewById(R.id.address)).setText(number+" "+adname);
                        ((TextView)findViewById(R.id.phone)).setText(phone);
                        ((TextView)findViewById(R.id.password)).setText(password);
                        Picasso.with(HomeActivity.this)
                                .load(medium)
                                .placeholder(R.drawable.ic_baseline_supervised_user_circle_24)
                                .into(profileImage);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //pDialog.cancel();
                Log.i(TAG,"Error :" + error.toString());
            }
        });

        mRequestQueue.add(mStringRequest);
    }
}